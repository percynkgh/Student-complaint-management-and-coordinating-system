<?php
require_once '../config/security.php';
require_once '../config/complaint_functions.php';

if (file_exists('../vendor/autoload.php')) {
    require_once '../vendor/autoload.php';
}

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use Dompdf\Dompdf;
use Dompdf\Options;

Security::requireLogin();
if (!Security::hasRole('supervisor')) {
    header("Location: ../unauthorized.php");
    exit();
}

$db = (new Database())->getConnection();
$cm = new ComplaintManager();
$user_id = $_SESSION['user_id'];

$dept_stmt = $db->prepare("SELECT department FROM users WHERE user_id = ?");
$dept_stmt->execute([$user_id]);
$department = $dept_stmt->fetchColumn() ?: 'Unknown';

$date_from = $_GET['date_from'] ?? date('Y-m-d', strtotime('-3 months'));
$date_to = $_GET['date_to'] ?? date('Y-m-d');

// report_type: 'all_staff' (every staff member summarized) or 'staff' (one staff member, with their complaint list)
$report_type = $_GET['report_type'] ?? 'all_staff';
$staff_id = isset($_GET['staff_id']) ? (int)$_GET['staff_id'] : 0;

$department_staff = $cm->getDepartmentStaff($department);
$staff_perf = $cm->getDepartmentStaffPerformance($department);
$dept_perf = $cm->getDepartmentPerformanceSummary($department, $date_from, $date_to);
$summary = $dept_perf['summary'];
$categories = $dept_perf['categories'];

$selected_staff_name = '';
$staff_complaints = [];
if ($report_type === 'staff' && $staff_id) {
    foreach ($department_staff as $sm) {
        if ((int)$sm['user_id'] === $staff_id) { $selected_staff_name = $sm['full_name']; break; }
    }
    $staff_complaints = $cm->getStaffComplaintDetails($staff_id, $date_from, $date_to);
    // Narrow the summary table to just this one staff member
    $staff_perf = array_values(array_filter($staff_perf, fn($sp) => (int)$sp['user_id'] === $staff_id));
}

$export_format = $_GET['export'] ?? '';

// =========================================================================
// Exports
// =========================================================================
if ($export_format === 'csv') {
    exportCSV($department, $date_from, $date_to, $summary, $categories, $staff_perf, $report_type, $selected_staff_name, $staff_complaints);
} elseif ($export_format === 'excel') {
    exportExcel($department, $date_from, $date_to, $summary, $categories, $staff_perf, $report_type, $selected_staff_name, $staff_complaints);
} elseif ($export_format === 'pdf') {
    exportPDF($department, $date_from, $date_to, $summary, $categories, $staff_perf, $report_type, $selected_staff_name, $staff_complaints);
}

function exportCSV($department, $date_from, $date_to, $summary, $categories, $staff_perf, $report_type, $selected_staff_name, $staff_complaints) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . preg_replace('/[^A-Za-z0-9_-]/', '_', $department) . '_report.csv"');
    $out = fopen('php://output', 'w');

    fputcsv($out, ["Department Performance Report - $department"]);
    fputcsv($out, ["Report Type", $report_type === 'staff' ? "Individual Staff: $selected_staff_name" : "All Staff"]);
    fputcsv($out, ["Period", "$date_from to $date_to"]);
    fputcsv($out, []);
    fputcsv($out, ["Total Complaints", "Resolved", "Resolution Rate", "Unassigned", "Avg Resolution Time"]);
    fputcsv($out, [
        $summary['total_complaints'] ?? 0, $summary['resolved_count'] ?? 0, ($summary['resolution_rate'] ?? 0) . '%',
        $summary['unassigned_count'] ?? 0, formatDuration($summary['avg_resolution_hours'])
    ]);
    fputcsv($out, []);
    fputcsv($out, ["Top Categories"]);
    fputcsv($out, ["Category", "Total"]);
    foreach ($categories as $c) fputcsv($out, [$c['category_name'], $c['total']]);
    fputcsv($out, []);
    fputcsv($out, [$report_type === 'staff' ? "Staff Summary: $selected_staff_name" : "Staff Performance (All Staff)"]);
    fputcsv($out, ["Staff Member", "Total Assigned", "Resolved", "Pending", "Avg Resolution Time"]);
    foreach ($staff_perf as $sp) {
        fputcsv($out, [$sp['full_name'], $sp['total_assigned'], $sp['resolved_count'], $sp['pending_count'],
            formatDuration($sp['avg_resolution_hours'])]);
    }
    if ($report_type === 'staff' && !empty($staff_complaints)) {
        fputcsv($out, []);
        fputcsv($out, ["Complaints Handled by $selected_staff_name"]);
        fputcsv($out, ["Complaint #", "Title", "Category", "Priority", "Status", "Assignment Status", "Assigned At", "Resolved At"]);
        foreach ($staff_complaints as $c) {
            fputcsv($out, [$c['complaint_number'], $c['title'], $c['category_name'], $c['priority'], $c['status'],
                $c['assignment_status'], $c['assigned_at'], $c['resolved_at']]);
        }
    }
    fclose($out);
    exit();
}

function exportExcel($department, $date_from, $date_to, $summary, $categories, $staff_perf, $report_type, $selected_staff_name, $staff_complaints) {
    if (!class_exists('PhpOffice\PhpSpreadsheet\Spreadsheet')) {
        die('PhpSpreadsheet library not found.');
    }
    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();
    $sheet->setTitle('Report');

    $sheet->setCellValue('A1', strtoupper($department) . ' DEPARTMENT REPORT');
    $sheet->mergeCells('A1:E1');
    $sheet->getStyle('A1')->getFont()->setBold(true)->setSize(15);
    $sheet->getStyle('A1')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

    $sheet->setCellValue('A3', 'Report Type:');
    $sheet->setCellValue('B3', $report_type === 'staff' ? "Individual Staff - $selected_staff_name" : 'All Staff');
    $sheet->setCellValue('A4', 'Period:');
    $sheet->setCellValue('B4', "$date_from to $date_to");
    $sheet->getStyle('A3:A4')->getFont()->setBold(true);

    $row = 6;
    $sheet->setCellValue("A$row", 'Total Complaints');
    $sheet->setCellValue("B$row", 'Resolved');
    $sheet->setCellValue("C$row", 'Resolution Rate');
    $sheet->setCellValue("D$row", 'Unassigned');
    $sheet->setCellValue("E$row", 'Avg Resolution Time');
    $sheet->getStyle("A$row:E$row")->getFont()->setBold(true);
    $row++;
    $sheet->setCellValue("A$row", $summary['total_complaints'] ?? 0);
    $sheet->setCellValue("B$row", $summary['resolved_count'] ?? 0);
    $sheet->setCellValue("C$row", ($summary['resolution_rate'] ?? 0) . '%');
    $sheet->setCellValue("D$row", $summary['unassigned_count'] ?? 0);
    $sheet->setCellValue("E$row", formatDuration($summary['avg_resolution_hours']));

    $row += 3;
    $sheet->setCellValue("A$row", 'Top Categories');
    $sheet->getStyle("A$row")->getFont()->setBold(true);
    $row++;
    $sheet->setCellValue("A$row", 'Category'); $sheet->setCellValue("B$row", 'Total');
    $sheet->getStyle("A$row:B$row")->getFont()->setBold(true);
    $row++;
    foreach ($categories as $c) {
        $sheet->setCellValue("A$row", $c['category_name']);
        $sheet->setCellValue("B$row", $c['total']);
        $row++;
    }

    $row += 2;
    $sheet->setCellValue("A$row", $report_type === 'staff' ? "Staff Summary: $selected_staff_name" : 'Staff Performance');
    $sheet->getStyle("A$row")->getFont()->setBold(true);
    $row++;
    $sheet->setCellValue("A$row", 'Staff Member'); $sheet->setCellValue("B$row", 'Assigned');
    $sheet->setCellValue("C$row", 'Resolved'); $sheet->setCellValue("D$row", 'Pending'); $sheet->setCellValue("E$row", 'Avg Hours');
    $sheet->getStyle("A$row:E$row")->getFont()->setBold(true);
    $row++;
    foreach ($staff_perf as $sp) {
        $sheet->setCellValue("A$row", $sp['full_name']);
        $sheet->setCellValue("B$row", $sp['total_assigned']);
        $sheet->setCellValue("C$row", $sp['resolved_count']);
        $sheet->setCellValue("D$row", $sp['pending_count']);
        $sheet->setCellValue("E$row", formatDuration($sp['avg_resolution_hours']));
        $row++;
    }

    if ($report_type === 'staff' && !empty($staff_complaints)) {
        $row += 2;
        $sheet->setCellValue("A$row", "Complaints Handled by $selected_staff_name");
        $sheet->getStyle("A$row")->getFont()->setBold(true);
        $row++;
        $headers = ['Complaint #', 'Title', 'Category', 'Priority', 'Status', 'Assignment Status', 'Assigned At', 'Resolved At'];
        $col = 'A';
        foreach ($headers as $h) { $sheet->setCellValue("$col$row", $h); $col++; }
        $sheet->getStyle("A$row:H$row")->getFont()->setBold(true);
        $row++;
        foreach ($staff_complaints as $c) {
            $sheet->setCellValue("A$row", $c['complaint_number']);
            $sheet->setCellValue("B$row", $c['title']);
            $sheet->setCellValue("C$row", $c['category_name']);
            $sheet->setCellValue("D$row", $c['priority']);
            $sheet->setCellValue("E$row", $c['status']);
            $sheet->setCellValue("F$row", $c['assignment_status']);
            $sheet->setCellValue("G$row", $c['assigned_at']);
            $sheet->setCellValue("H$row", $c['resolved_at']);
            $row++;
        }
    }

    foreach (range('A', 'H') as $col) $sheet->getColumnDimension($col)->setAutoSize(true);

    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . preg_replace('/[^A-Za-z0-9_-]/', '_', $department) . '_report.xlsx"');
    $writer = new Xlsx($spreadsheet);
    $writer->save('php://output');
    exit();
}

function exportPDF($department, $date_from, $date_to, $summary, $categories, $staff_perf, $report_type, $selected_staff_name, $staff_complaints) {
    if (!class_exists('Dompdf\Dompdf')) {
        die('Dompdf library not found.');
    }
    $options = new Options();
    $options->set('isHtml5ParserEnabled', true);
    $dompdf = new Dompdf($options);

    $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h1 { color: #333; text-align: center; margin-bottom: 0; }
        h2 { color: #0a63bc; text-align: center; margin-top: 5px; }
        h3 { color: #0a63bc; border-bottom: 2px solid #0a63bc; padding-bottom: 5px; }
        table { width: 100%; border-collapse: collapse; margin: 15px 0; }
        th { background: #0a63bc; color: white; padding: 8px; text-align: left; font-size: 12px; }
        td { padding: 6px 8px; border-bottom: 1px solid #ddd; font-size: 12px; }
        .date { color: #666; font-size: 11px; text-align: center; }
        .summary-grid { width: 100%; }
        .summary-grid td { text-align: center; background: #f8f9fa; font-size: 20px; font-weight: bold; color: #0a63bc; }
        .summary-label { font-size: 11px !important; font-weight: normal !important; color: #666 !important; background: none !important; }
    </style></head><body>
        <h1>' . htmlspecialchars($department) . ' Department Report</h1>
        <h2>' . ($report_type === 'staff' ? 'Individual Staff: ' . htmlspecialchars($selected_staff_name) : 'All Staff Performance') . '</h2>
        <p class="date">Period: ' . htmlspecialchars($date_from) . ' to ' . htmlspecialchars($date_to) . ' &middot; Generated ' . date('Y-m-d H:i') . '</p>

        <h3>Department Performance</h3>
        <table class="summary-grid">
            <tr>
                <td>' . ($summary['total_complaints'] ?? 0) . '</td>
                <td>' . ($summary['resolved_count'] ?? 0) . '</td>
                <td>' . ($summary['resolution_rate'] ?? 0) . '%</td>
                <td>' . ($summary['unassigned_count'] ?? 0) . '</td>
                <td>' . (formatDuration($summary['avg_resolution_hours'])) . '</td>
            </tr>
            <tr>
                <td class="summary-label">Total</td>
                <td class="summary-label">Resolved</td>
                <td class="summary-label">Resolution Rate</td>
                <td class="summary-label">Unassigned</td>
                <td class="summary-label">Avg Hours</td>
            </tr>
        </table>

        <h3>Top Categories</h3>
        <table><tr><th>Category</th><th>Total</th></tr>';
    foreach ($categories as $c) {
        $html .= '<tr><td>' . htmlspecialchars($c['category_name']) . '</td><td>' . $c['total'] . '</td></tr>';
    }
    $html .= '</table>

        <h3>' . ($report_type === 'staff' ? 'Staff Summary' : 'Staff Performance') . '</h3>
        <table><tr><th>Staff Member</th><th>Assigned</th><th>Resolved</th><th>Pending</th><th>Avg Hours</th></tr>';
    foreach ($staff_perf as $sp) {
        $html .= '<tr><td>' . htmlspecialchars($sp['full_name']) . '</td><td>' . $sp['total_assigned'] . '</td><td>' . $sp['resolved_count'] . '</td><td>' . $sp['pending_count'] . '</td><td>' . (formatDuration($sp['avg_resolution_hours'])) . '</td></tr>';
    }
    $html .= '</table>';

    if ($report_type === 'staff' && !empty($staff_complaints)) {
        $html .= '<h3>Complaints Handled by ' . htmlspecialchars($selected_staff_name) . '</h3>
        <table><tr><th>#</th><th>Title</th><th>Category</th><th>Priority</th><th>Status</th><th>Assigned</th><th>Resolved</th></tr>';
        foreach ($staff_complaints as $c) {
            $html .= '<tr><td>' . htmlspecialchars($c['complaint_number']) . '</td><td>' . htmlspecialchars($c['title']) . '</td><td>' . htmlspecialchars($c['category_name'] ?? '') . '</td><td>' . htmlspecialchars($c['priority']) . '</td><td>' . htmlspecialchars($c['status']) . '</td><td>' . htmlspecialchars($c['assigned_at'] ?? '-') . '</td><td>' . htmlspecialchars($c['resolved_at'] ?? '-') . '</td></tr>';
        }
        $html .= '</table>';
    }
    $html .= '</body></html>';

    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();
    $dompdf->stream(preg_replace('/[^A-Za-z0-9_-]/', '_', $department) . '_report.pdf', ['Attachment' => true]);
    exit();
}

function isFilterActive($f) {
    return (isset($_GET['report_type']) && $_GET['report_type'] == $f) ? 'active-filter' : '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supervisor Reports</title>
    <link rel="stylesheet" href="css/supervisor.css">
    <style>
        .filter-bar { background: #fff; padding: 18px; border-radius: 10px; margin-bottom: 20px; display: flex; gap: 12px; align-items: flex-end; flex-wrap: wrap; }
        .filter-bar .form-group { display: flex; flex-direction: column; gap: 4px; }
        .filter-bar input, .filter-bar select { padding: 8px; border: 1px solid #ddd; border-radius: 6px; }
        .filter-bar button { padding: 9px 20px; background: #0a63bc; color: #fff; border: none; border-radius: 6px; cursor: pointer; font-weight: 600; }
        .report-card { background: #fff; border-radius: 10px; padding: 20px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
        .summary-stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px,1fr)); gap: 15px; margin-bottom: 10px; }
        .summary-stat { text-align: center; background: #f8f9fa; border-radius: 8px; padding: 15px; }
        .summary-stat .number { font-size: 24px; font-weight: bold; color: #0a63bc; }
        .summary-stat .label { font-size: 12px; color: #666; }
        table.report-table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        table.report-table th, table.report-table td { padding: 10px; border-bottom: 1px solid #eee; text-align: left; font-size: 13px; }
        table.report-table th { color: #666; text-transform: uppercase; font-size: 11px; }
        .export-group { display: flex; gap: 8px; }
        .preview-heading { margin: 25px 0 4px; color: #2c3e50; font-size: 20px; }
        .preview-subtitle { color: #7f8c8d; font-size: 13px; margin: 0 0 15px; }
        .download-card { background: #f0f7f4; border: 1px dashed #28a745; text-align: left; }
        .download-card h3 { margin-top: 0; color: #1e7e34; }
        .export-btn { background: #28a745; color: #fff; padding: 9px 16px; border-radius: 6px; text-decoration: none; font-weight: 600; font-size: 13px; }
        .export-btn.excel { background: #217346; }
        .export-btn.pdf { background: #c0392b; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div>
                <h1>Department &amp; Staff Reports</h1>
                <span class="department-badge"><?php echo htmlspecialchars($department); ?> Department</span>
            </div>
            <div class="header-actions">
                <a href="dashboard.php" class="back-btn">← Dashboard</a>
                <a href="../auth/logout.php" class="logout-btn">Logout</a>
            </div>
        </div>

        <form method="GET" class="filter-bar">
            <div class="form-group">
                <label>Report Type</label>
                <select name="report_type" id="reportTypeSelect" onchange="document.getElementById('staffPicker').style.display = this.value === 'staff' ? 'flex' : 'none';">
                    <option value="all_staff" <?php echo $report_type == 'all_staff' ? 'selected' : ''; ?>>All Staff</option>
                    <option value="staff" <?php echo $report_type == 'staff' ? 'selected' : ''; ?>>Specific Staff Member</option>
                </select>
            </div>
            <div class="form-group" id="staffPicker" style="<?php echo $report_type == 'staff' ? '' : 'display:none;'; ?>">
                <label>Staff Member</label>
                <select name="staff_id">
                    <option value="">Select...</option>
                    <?php foreach ($department_staff as $sm): ?>
                        <option value="<?php echo $sm['user_id']; ?>" <?php echo $staff_id == $sm['user_id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($sm['full_name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>From</label>
                <input type="date" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>">
            </div>
            <div class="form-group">
                <label>To</label>
                <input type="date" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>">
            </div>
            <button type="submit">Apply</button>
            <?php $q = "report_type=$report_type&staff_id=$staff_id&date_from=" . urlencode($date_from) . "&date_to=" . urlencode($date_to); ?>
        </form>

        <h2 class="preview-heading">📋 Report Preview</h2>
        <p class="preview-subtitle">Review the report below, then download it in your preferred format at the bottom of the page.</p>

        <div class="report-card">
            <h3>Department Performance</h3>
            <div class="summary-stats">
                <div class="summary-stat"><div class="number"><?php echo $summary['total_complaints'] ?? 0; ?></div><div class="label">Total Complaints</div></div>
                <div class="summary-stat"><div class="number"><?php echo $summary['resolved_count'] ?? 0; ?></div><div class="label">Resolved</div></div>
                <div class="summary-stat"><div class="number"><?php echo $summary['resolution_rate'] ?? 0; ?>%</div><div class="label">Resolution Rate</div></div>
                <div class="summary-stat"><div class="number"><?php echo $summary['unassigned_count'] ?? 0; ?></div><div class="label">Unassigned</div></div>
                <div class="summary-stat"><div class="number"><?php echo formatDuration($summary['avg_resolution_hours']); ?></div><div class="label">Avg. Resolution Time</div></div>
            </div>

            <h4 style="margin-top:20px;">Top Complaint Categories</h4>
            <table class="report-table">
                <thead><tr><th>Category</th><th>Total</th></tr></thead>
                <tbody>
                <?php if (empty($categories)): ?><tr><td colspan="2">No data for this period.</td></tr><?php endif; ?>
                <?php foreach ($categories as $c): ?>
                    <tr><td><?php echo htmlspecialchars($c['category_name']); ?></td><td><?php echo $c['total']; ?></td></tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="report-card">
            <h3><?php echo $report_type === 'staff' && $selected_staff_name ? 'Staff Summary: ' . htmlspecialchars($selected_staff_name) : 'Staff Performance (All Staff)'; ?></h3>
            <table class="report-table">
                <thead>
                    <tr><th>Staff Member</th><th>Email</th><th>Total Assigned</th><th>Resolved</th><th>Pending</th><th>Avg. Resolution Time</th></tr>
                </thead>
                <tbody>
                <?php if (empty($staff_perf)): ?>
                    <tr><td colspan="6"><?php echo $report_type === 'staff' ? 'Select a staff member above and click Apply.' : 'No staff members in this department yet.'; ?></td></tr>
                <?php endif; ?>
                <?php foreach ($staff_perf as $sp): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($sp['full_name']); ?></td>
                        <td><?php echo htmlspecialchars($sp['email']); ?></td>
                        <td><?php echo $sp['total_assigned']; ?></td>
                        <td><?php echo $sp['resolved_count']; ?></td>
                        <td><?php echo $sp['pending_count']; ?></td>
                        <td><?php echo formatDuration($sp['avg_resolution_hours']); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php if ($report_type === 'staff' && $selected_staff_name): ?>
        <div class="report-card">
            <h3>Complaints Handled by <?php echo htmlspecialchars($selected_staff_name); ?></h3>
            <table class="report-table">
                <thead>
                    <tr><th>Complaint #</th><th>Title</th><th>Category</th><th>Priority</th><th>Status</th><th>Assigned</th><th>Resolved</th></tr>
                </thead>
                <tbody>
                <?php if (empty($staff_complaints)): ?>
                    <tr><td colspan="7">No complaints for this period.</td></tr>
                <?php endif; ?>
                <?php foreach ($staff_complaints as $c): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($c['complaint_number']); ?></td>
                        <td><?php echo htmlspecialchars($c['title']); ?></td>
                        <td><?php echo htmlspecialchars($c['category_name'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($c['priority']); ?></td>
                        <td><?php echo ucfirst(str_replace('_', ' ', $c['status'])); ?></td>
                        <td><?php echo $c['assigned_at'] ? date('M d, Y', strtotime($c['assigned_at'])) : '-'; ?></td>
                        <td><?php echo $c['resolved_at'] ? date('M d, Y', strtotime($c['resolved_at'])) : '-'; ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>

        <div class="report-card download-card">
            <h3>⬇ Download This Report</h3>
            <p class="preview-subtitle">Same data shown above, exported as a file.</p>
            <div class="export-group">
                <a class="export-btn" href="?<?php echo $q; ?>&export=csv">⬇ CSV</a>
                <a class="export-btn excel" href="?<?php echo $q; ?>&export=excel">⬇ Excel</a>
                <a class="export-btn pdf" href="?<?php echo $q; ?>&export=pdf">⬇ PDF</a>
            </div>
        </div>
    </div>
</body>
</html>

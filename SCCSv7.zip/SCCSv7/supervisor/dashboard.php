<?php
require_once '../config/security.php';
require_once '../config/complaint_functions.php';

Security::requireLogin();
if (!Security::hasRole('supervisor')) {
    header("Location: ../unauthorized.php");
    exit();
}

$db = (new Database())->getConnection();
$cm = new ComplaintManager();
$user_id = $_SESSION['user_id'];

$dept_stmt = $db->prepare("SELECT department FROM users WHERE user_id = ?");
$dept_stmt->execute([$user_id]);
$department = $dept_stmt->fetchColumn() ?: 'Unknown';

$filter = $_GET['filter'] ?? 'all';
$msg = $_GET['msg'] ?? '';

// -------- Handle quick-assign from the dashboard --------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['quick_assign']) && isset($_POST['csrf_token']) && Security::verifyCSRFToken($_POST['csrf_token'])) {
    $complaint_id = (int)$_POST['complaint_id'];
    $assigned_to = (int)$_POST['assigned_to'];
    $result = $cm->assignComplaintToStaff($complaint_id, $assigned_to, $user_id);
    $redirect = "dashboard.php?msg=" . ($result['success'] ? 'assigned' : 'assign_failed') . ($filter != 'all' ? "&filter=$filter" : "");
    header("Location: $redirect");
    exit();
}

// -------- Department-wide complaint query (this is the Supervisor's core view) --------
$query = "SELECT c.*, cat.category_name, u.full_name as student_name, u.email as student_email,
          a.full_name as assigned_to_name,
          (SELECT COUNT(*) FROM batch_members WHERE complaint_id = c.complaint_id) as affected_count,
          DATEDIFF(NOW(), c.created_at) as days_old
          FROM complaints c
          LEFT JOIN complaint_categories cat ON c.category_id = cat.category_id
          LEFT JOIN users u ON c.user_id = u.user_id
          LEFT JOIN users a ON c.assigned_to = a.user_id
          WHERE c.department_assigned = ?";

if ($filter == 'unassigned') {
    $query .= " AND (c.assignment_status = 'unassigned' OR c.assignment_status IS NULL OR c.assigned_to IS NULL)";
} elseif ($filter == 'unresolved') {
    $query .= " AND LOWER(TRIM(c.status)) != 'resolved'";
} elseif ($filter == 'assigned') {
    $query .= " AND c.assignment_status = 'assigned'";
} elseif ($filter == 'awaiting_confirmation') {
    $query .= " AND c.assignment_status = 'awaiting_confirmation'";
} elseif ($filter == 'resolved') {
    $query .= " AND LOWER(TRIM(c.status)) = 'resolved'";
} elseif ($filter == 'overdue') {
    $query .= " AND DATEDIFF(NOW(), c.created_at) > 7 AND LOWER(TRIM(c.status)) != 'resolved'";
} elseif ($filter == 'urgent') {
    $query .= " AND LOWER(TRIM(c.priority)) = 'urgent'";
}

$query .= " ORDER BY 
            CASE WHEN c.assignment_status = 'unassigned' OR c.assignment_status IS NULL OR c.assigned_to IS NULL THEN 0 ELSE 1 END,
            CASE 
                WHEN LOWER(TRIM(c.priority)) = 'urgent' THEN 1
                WHEN LOWER(TRIM(c.priority)) = 'high' THEN 2
                WHEN LOWER(TRIM(c.priority)) = 'medium' THEN 3
                WHEN LOWER(TRIM(c.priority)) = 'low' THEN 4
                ELSE 5
            END,
            c.created_at ASC";

$stmt = $db->prepare($query);
$stmt->execute([$department]);
$complaints = $stmt->fetchAll(PDO::FETCH_ASSOC);

// -------- Stats for the whole department --------
$all_stmt = $db->prepare("SELECT * FROM complaints WHERE department_assigned = ?");
$all_stmt->execute([$department]);
$all_complaints = $all_stmt->fetchAll(PDO::FETCH_ASSOC);

$stats = ['total' => count($all_complaints), 'unresolved' => 0, 'unassigned' => 0, 'assigned' => 0, 'awaiting_confirmation' => 0, 'resolved' => 0, 'overdue' => 0, 'urgent' => 0];
foreach ($all_complaints as $c) {
    $astatus = $c['assignment_status'] ?? 'unassigned';
    if (empty($c['assigned_to']) || $astatus == 'unassigned') $stats['unassigned']++;
    elseif ($astatus == 'assigned') $stats['assigned']++;
    elseif ($astatus == 'awaiting_confirmation') $stats['awaiting_confirmation']++;

    $is_resolved = strtolower(trim($c['status'] ?? '')) == 'resolved';
    if ($is_resolved) $stats['resolved']++;
    else $stats['unresolved']++;
    if (strtolower(trim($c['priority'] ?? '')) == 'urgent') $stats['urgent']++;
    $days_old = isset($c['created_at']) ? (int)((time() - strtotime($c['created_at'])) / 86400) : 0;
    if ($days_old > 7 && !$is_resolved) $stats['overdue']++;
}

// -------- Staff performance summary for this department --------
$staff_perf = $cm->getDepartmentStaffPerformance($department);

// -------- Staff list for quick-assign dropdowns --------
$department_staff = $cm->getDepartmentStaff($department);

$csrf_token = Security::generateCSRFToken();

function isFilterActive($f) {
    return (isset($_GET['filter']) && $_GET['filter'] == $f) ? 'active-filter' : '';
}

function priorityClass($priority) {
    switch (strtolower(trim($priority ?? 'medium'))) {
        case 'urgent': return 'priority-urgent';
        case 'high': return 'priority-high';
        case 'low': return 'priority-low';
        default: return 'priority-medium';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supervisor Dashboard</title>
    <link rel="stylesheet" href="css/supervisor.css">
    <style>
        .staff-perf-table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        .staff-perf-table th, .staff-perf-table td { padding: 10px; text-align: left; border-bottom: 1px solid #eee; font-size: 13px; }
        .staff-perf-table th { color: #666; text-transform: uppercase; font-size: 11px; }
        .quick-assign-form { display: flex; gap: 8px; margin-top: 10px; align-items: center; flex-wrap: wrap; }
        .quick-assign-form select { padding: 6px 10px; border-radius: 6px; border: 1px solid #ddd; }
        .quick-assign-form button { padding: 6px 14px; border-radius: 6px; border: none; background: #0a63bc; color: #fff; cursor: pointer; font-weight: 600; }
        .assign-badge { display:inline-block; padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: 700; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div>
                <h1>Supervisor Dashboard</h1>
                <span class="department-badge"><?php echo htmlspecialchars($department); ?> Department</span>
            </div>
            <div class="header-actions">
                <a href="notifications.php" class="back-btn" style="position: relative;">
                    Notifications
                    <?php
                    $unread_notifs = $cm->getUnreadNotificationCount($user_id);
                    if ($unread_notifs > 0): 
                    ?>
                        <span class="notification-badge">
                            <?php echo $unread_notifs; ?>
                        </span>
                    <?php endif; ?>
                </a>
                <a href="reports.php" class="back-btn">Reports</a>
                <a href="direct_messages.php" class="back-btn">Messages</a>
                <a href="profile.php" class="back-btn">Profile</a>
                <a href="../auth/logout.php" class="logout-btn">Logout</a>
            </div>
        </div>

        <?php if ($msg == 'assigned'): ?><div class="message-alert message-success">Complaint assigned successfully.</div><?php endif; ?>
        <?php if ($msg == 'assign_failed'): ?><div class="message-alert message-error">Could not assign that complaint. Please try again.</div><?php endif; ?>

        <div class="stats-grid">
            <div class="stat-card <?php echo isFilterActive('all'); ?>" onclick="window.location.href='?filter=all'">
                <div class="stat-number"><?php echo $stats['total']; ?></div>
                <div class="stat-label">Total in Department</div>
            </div>
            <div class="stat-card <?php echo isFilterActive('unresolved'); ?>" onclick="window.location.href='?filter=unresolved'">
                <div class="stat-number"><?php echo $stats['unresolved']; ?></div>
                <div class="stat-label">Unresolved (All Open)</div>
            </div>
            <div class="stat-card <?php echo isFilterActive('unassigned'); ?>" onclick="window.location.href='?filter=unassigned'">
                <div class="stat-number"><?php echo $stats['unassigned']; ?></div>
                <div class="stat-label">Unassigned (Needs Action)</div>
            </div>
            <div class="stat-card <?php echo isFilterActive('assigned'); ?>" onclick="window.location.href='?filter=assigned'">
                <div class="stat-number"><?php echo $stats['assigned']; ?></div>
                <div class="stat-label">Assigned &amp; In Progress</div>
            </div>
            <div class="stat-card <?php echo isFilterActive('awaiting_confirmation'); ?>" onclick="window.location.href='?filter=awaiting_confirmation'">
                <div class="stat-number"><?php echo $stats['awaiting_confirmation']; ?></div>
                <div class="stat-label">Awaiting My Confirmation</div>
            </div>
            <div class="stat-card <?php echo isFilterActive('resolved'); ?>" onclick="window.location.href='?filter=resolved'">
                <div class="stat-number"><?php echo $stats['resolved']; ?></div>
                <div class="stat-label">Resolved</div>
            </div>
            <div class="stat-card <?php echo isFilterActive('overdue'); ?>" onclick="window.location.href='?filter=overdue'">
                <div class="stat-number"><?php echo $stats['overdue']; ?></div>
                <div class="stat-label">Overdue (&gt;7 days)</div>
            </div>
            <div class="stat-card <?php echo isFilterActive('urgent'); ?>" onclick="window.location.href='?filter=urgent'">
                <div class="stat-number"><?php echo $stats['urgent']; ?></div>
                <div class="stat-label">Urgent Priority</div>
            </div>
        </div>

        <!-- Staff performance summary -->
        <div class="complaints-section" style="margin-bottom: 25px;">
            <h2>Staff Performance <a href="reports.php" style="font-size:13px; font-weight:normal; margin-left:10px;">View full reports →</a></h2>
            <?php if (empty($staff_perf)): ?>
                <p style="color:#999;">No staff members in this department yet.</p>
            <?php else: ?>
            <table class="staff-perf-table">
                <thead>
                    <tr><th>Staff Member</th><th>Assigned</th><th>Resolved</th><th>Pending</th><th>Avg. Resolution Time</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($staff_perf as $sp): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($sp['full_name']); ?></td>
                        <td><?php echo $sp['total_assigned']; ?></td>
                        <td><?php echo $sp['resolved_count']; ?></td>
                        <td><?php echo $sp['pending_count']; ?></td>
                        <td><?php echo formatDuration($sp['avg_resolution_hours']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>

        <!-- Complaints List -->
        <div class="complaints-section">
            <h2>
                <?php
                    if ($filter == 'unassigned') echo "Unassigned Complaints";
                    elseif ($filter == 'unresolved') echo "Unresolved Complaints (All Open)";
                    elseif ($filter == 'assigned') echo "Assigned &amp; In Progress";
                    elseif ($filter == 'awaiting_confirmation') echo "Awaiting My Confirmation";
                    elseif ($filter == 'resolved') echo "Resolved Complaints";
                    elseif ($filter == 'overdue') echo "Overdue Complaints";
                    elseif ($filter == 'urgent') echo "Urgent Complaints";
                    else echo "All Department Complaints";
                ?>
                <?php if ($filter != 'all'): ?><a href="dashboard.php" class="clear-filter">Clear filter</a><?php endif; ?>
            </h2>

            <?php if (empty($complaints)): ?>
                <div class="empty-state">No complaints found for this view.</div>
            <?php endif; ?>

            <div class="complaint-list">
                <?php foreach ($complaints as $complaint): ?>
                    <?php
                    $a_status = $complaint['assignment_status'] ?? 'unassigned';
                    $a_colors = ['unassigned' => '#856404;background:#fff3cd', 'assigned' => '#004085;background:#cce5ff', 'awaiting_confirmation' => '#7a3e00;background:#ffe3c4', 'resolved' => '#155724;background:#d4edda'];
                    $a_style = $a_colors[$a_status] ?? $a_colors['unassigned'];
                    ?>
                    <div class="complaint-card">
                        <div class="complaint-header">
                            <div>
                                <span class="complaint-number">#<?php echo htmlspecialchars($complaint['complaint_number']); ?></span>
                                <span class="complaint-title"><?php echo htmlspecialchars($complaint['title']); ?></span>
                            </div>
                            <div class="badge-container">
                                <span class="priority-badge <?php echo priorityClass($complaint['priority']); ?>"><?php echo strtoupper($complaint['priority']); ?></span>
                                <span class="assign-badge" style="color:<?php echo explode(';', $a_style)[0]; ?>;<?php echo explode(';', $a_style)[1] ?? ''; ?>">
                                    <?php
                                    if ($a_status === 'unassigned' || empty($complaint['assigned_to'])) echo 'Unassigned';
                                    elseif ($a_status === 'assigned') echo 'Assigned: ' . htmlspecialchars($complaint['assigned_to_name'] ?? '');
                                    elseif ($a_status === 'awaiting_confirmation') echo 'Awaiting Confirmation: ' . htmlspecialchars($complaint['assigned_to_name'] ?? '');
                                    elseif ($a_status === 'resolved') echo 'Confirmed Resolved';
                                    ?>
                                </span>
                                <?php if (($complaint['days_old'] ?? 0) > 7): ?><span class="days-old"><?php echo $complaint['days_old']; ?> days old</span><?php endif; ?>
                            </div>
                        </div>
                        <div class="complaint-meta">
                            <span>Reported by: <?php echo htmlspecialchars($complaint['student_name'] ?? 'Unknown'); ?></span>
                            <span>Category: <?php echo htmlspecialchars($complaint['category_name'] ?? 'N/A'); ?></span>
                            <span>Status: <?php echo ucfirst(str_replace('_', ' ', $complaint['status'])); ?></span>
                        </div>
                        <div class="complaint-description"><?php echo htmlspecialchars(substr($complaint['description'], 0, 150)); ?>...</div>

                        <?php if ($a_status === 'unassigned' || empty($complaint['assigned_to'])): ?>
                            <?php if (!empty($department_staff)): ?>
                            <form method="POST" action="" class="quick-assign-form">
                                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                                <input type="hidden" name="complaint_id" value="<?php echo $complaint['complaint_id']; ?>">
                                <select name="assigned_to" required>
                                    <option value="">Assign to staff member...</option>
                                    <?php foreach ($department_staff as $sm): ?>
                                        <option value="<?php echo $sm['user_id']; ?>"><?php echo htmlspecialchars($sm['full_name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <button type="submit" name="quick_assign">Assign</button>
                            </form>
                            <?php else: ?>
                                <p style="color:#999; font-size:13px;">No staff members in this department yet to assign to.</p>
                            <?php endif; ?>
                        <?php endif; ?>

                        <a href="view_complaint.php?id=<?php echo $complaint['complaint_id']; ?>" class="btn btn-view">View Details</a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</body>
</html>

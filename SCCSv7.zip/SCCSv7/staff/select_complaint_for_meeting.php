<?php

require_once '../config/security.php';
require_once '../config/complaint_functions.php';

Security::requireLogin();
if (!Security::hasRole('staff') && !Security::hasRole('admin') && !Security::hasRole('dean')) {
    header("Location: ../unauthorized.php");
    exit();
}

$db = (new Database())->getConnection();
$user_id = $_SESSION['user_id'];

// Get staff's department
$query = "SELECT department FROM users WHERE user_id = ?";
$stmt = $db->prepare($query);
$stmt->execute([$user_id]);
$department = $stmt->fetchColumn();

// Get complaints this staff can access
$query = "SELECT complaint_id, complaint_number, title, status, priority 
          FROM complaints 
          WHERE department_assigned = ? OR assigned_to = ?
          ORDER BY created_at DESC";
$stmt = $db->prepare($query);
$stmt->execute([$department, $user_id]);
$complaints = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Start Video Meeting</title>
    <link rel="stylesheet" href="css/staff.css">
</head>
<body>
    <div class="container-small">
        <div class="header-gradient">
            <h1>Start Video Meeting</h1>
            <a href="dashboard.php" class="back-btn">← Back</a>
        </div>
        
        <?php if (empty($complaints)): ?>
            <div class="empty-state">
                <p>No complaints available</p>
            </div>
        <?php else: ?>
            <div class="complaint-list">
                <?php foreach ($complaints as $complaint): ?>
                    <a href="webrtc_meeting.php?complaint_id=<?php echo $complaint['complaint_id']; ?>" class="complaint-item">
                        <span class="complaint-number">#<?php echo $complaint['complaint_number']; ?></span>
                        <span class="complaint-title"><?php echo htmlspecialchars($complaint['title']); ?></span>
                        <span class="status-badge status-<?php echo $complaint['status']; ?>">
                            <?php echo ucfirst($complaint['status']); ?>
                        </span>
                        <span class="call-btn">Start Call →</span>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
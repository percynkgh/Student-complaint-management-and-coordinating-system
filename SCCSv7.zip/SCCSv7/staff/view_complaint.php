<?php
require_once '../config/security.php';
require_once '../config/complaint_functions.php';

Security::requireLogin();
if (!Security::hasRole('staff')) {
    header("Location: ../unauthorized.php");
    exit();
}

$db = (new Database())->getConnection();
$cm = new ComplaintManager();
$user_id = $_SESSION['user_id'];

$complaint_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$complaint_id) {
    header("Location: dashboard.php");
    exit();
}

// Staff's own department
$dept_stmt = $db->prepare("SELECT department FROM users WHERE user_id = ?");
$dept_stmt->execute([$user_id]);
$my_department = $dept_stmt->fetchColumn();

$error = '';
$success = '';

// -------- Load complaint --------
function loadComplaint($db, $complaint_id) {
    $query = "SELECT c.*, cat.category_name,
              u.full_name as student_name, u.email as student_email, u.student_id,
              a.full_name as assigned_to_name,
              b.full_name as assigned_by_name
              FROM complaints c
              LEFT JOIN complaint_categories cat ON c.category_id = cat.category_id
              LEFT JOIN users u ON c.user_id = u.user_id
              LEFT JOIN users a ON c.assigned_to = a.user_id
              LEFT JOIN users b ON c.assigned_by = b.user_id
              WHERE c.complaint_id = ?";
    $stmt = $db->prepare($query);
    $stmt->execute([$complaint_id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

$complaint = loadComplaint($db, $complaint_id);
if (!$complaint) {
    header("Location: dashboard.php");
    exit();
}
if ($complaint['department_assigned'] !== $my_department) {
    header("Location: ../unauthorized.php");
    exit();
}
// Staff can only open complaints specifically assigned to them - department-wide
// visibility (including unassigned complaints) belongs to the Supervisor now.
if (empty($complaint['assigned_to']) || (int)$complaint['assigned_to'] !== (int)$user_id) {
    header("Location: ../unauthorized.php");
    exit();
}

// -------- Handle POST actions --------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['csrf_token']) && Security::verifyCSRFToken($_POST['csrf_token'])) {

    // Quick status update - working states only. Final outcomes (resolved)
    // are reserved for the Supervisor, who confirms with evidence before
    // the student is notified.
    if (isset($_POST['update_status'])) {
        $new_status = Security::sanitize($_POST['status']);
        $update_message = Security::sanitize($_POST['update_message'] ?? 'Status updated');
        $allowed_staff_statuses = ['under_review', 'in_progress'];

        if (!in_array($new_status, $allowed_staff_statuses)) {
            $error = "You can move a complaint to Under Review or In Progress. Final resolution is confirmed by your supervisor.";
        } else {
            try {
                $stmt = $db->prepare("UPDATE complaints SET status = ? WHERE complaint_id = ?");
                $stmt->execute([$new_status, $complaint_id]);
                $cm->addTimelineEntry($complaint_id, $new_status, $update_message, $user_id);
                $success = "Status updated successfully.";
            } catch (Exception $e) {
                $error = "Failed to update status.";
            }
        }
    }

    // Upload before/after evidence photo
    elseif (isset($_POST['upload_evidence'])) {
        if (empty($_FILES['evidence_file']['name'])) {
            $error = "Please choose a photo to upload.";
        } else {
            $evidence_type = in_array($_POST['evidence_type'] ?? '', ['before', 'after', 'general']) ? $_POST['evidence_type'] : 'general';
            $caption = Security::sanitize($_POST['evidence_caption'] ?? '');
            $result = $cm->uploadEvidence($_FILES['evidence_file'], $complaint_id, $user_id, $evidence_type, $caption);
            if ($result['success']) {
                $success = "Evidence photo uploaded.";
            } else {
                $error = $result['message'];
            }
        }
    }

    // Staff marks their work as resolved - this notifies the Supervisor,
    // who reviews the evidence and confirms before the student sees it.
    elseif (isset($_POST['mark_assignment_resolved'])) {
        $message = Security::sanitize($_POST['resolve_message'] ?? '');
        $result = $cm->markAssignmentResolved($complaint_id, $user_id, $message);
        if ($result['success']) {
            $success = "Marked as resolved. Your supervisor will review and confirm.";
        } else {
            $error = $result['message'];
        }
    }

    // Refresh complaint after any action
    $complaint = loadComplaint($db, $complaint_id);
}

// -------- Supporting data --------
$timeline_stmt = $db->prepare("SELECT t.*, u.full_name as updated_by_name 
                                FROM complaint_timeline t
                                LEFT JOIN users u ON t.updated_by = u.user_id
                                WHERE t.complaint_id = ?
                                ORDER BY t.created_at DESC");
$timeline_stmt->execute([$complaint_id]);
$timeline = $timeline_stmt->fetchAll(PDO::FETCH_ASSOC);

$attach_stmt = $db->prepare("SELECT * FROM complaint_attachments WHERE complaint_id = ?");
$attach_stmt->execute([$complaint_id]);
$attachments = $attach_stmt->fetchAll(PDO::FETCH_ASSOC);

$evidence = $cm->getComplaintEvidence($complaint_id);
$before_evidence = array_values(array_filter($evidence, fn($e) => $e['evidence_type'] === 'before'));
$after_evidence = array_values(array_filter($evidence, fn($e) => $e['evidence_type'] === 'after'));
$general_evidence = array_values(array_filter($evidence, fn($e) => $e['evidence_type'] === 'general'));

$templates = [];
try {
    $tmpl_stmt = $db->prepare("SELECT * FROM status_templates WHERE is_active = TRUE ORDER BY sort_order");
    $tmpl_stmt->execute();
    $templates = $tmpl_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $templates = [];
}

$csrf_token = Security::generateCSRFToken();

function priorityClass($priority) {
    switch (strtolower(trim($priority ?? 'medium'))) {
        case 'urgent': return 'priority-urgent';
        case 'high': return 'priority-high';
        case 'low': return 'priority-low';
        default: return 'priority-medium';
    }
}

$assignment_status = $complaint['assignment_status'] ?? 'assigned';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complaint <?php echo htmlspecialchars($complaint['complaint_number']); ?> - Staff</title>
    <link rel="stylesheet" href="css/staff.css">
    <style>
        .detail-wrap { max-width: 950px; margin: 0 auto; }
        .complaint-header-box {
            background: #0a63bc; color: #fff; padding: 22px 25px; border-radius: 10px; margin-bottom: 20px;
        }
        .complaint-header-box h2 { margin: 0 0 6px 0; }
        .meta-grid {
            display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 15px; background: #f8f9fa; padding: 20px; border-radius: 10px; margin-bottom: 20px;
        }
        .meta-item { display: flex; flex-direction: column; }
        .meta-label { font-size: 12px; color: #666; text-transform: uppercase; }
        .meta-value { font-size: 15px; font-weight: bold; color: #333; }
        .card-box { background: #fff; border-radius: 10px; padding: 20px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
        .card-box h3 { margin-top: 0; color: #2c3e50; border-bottom: 2px solid #f0f0f0; padding-bottom: 10px; }
        .assignment-banner {
            display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px;
            padding: 15px; border-radius: 8px; margin-bottom: 15px;
        }
        .assignment-banner.assigned { background: #e7f3ff; }
        .assignment-banner.awaiting_confirmation { background: #fde2c8; }
        .assignment-banner.resolved { background: #d4edda; }
        .evidence-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 12px; margin-top: 10px; }
        .evidence-item { border-radius: 8px; overflow: hidden; background: #f8f9fa; border: 1px solid #eee; }
        .evidence-item img { width: 100%; height: 120px; object-fit: cover; display: block; }
        .evidence-caption { font-size: 12px; padding: 6px 8px; color: #555; }
        .evidence-meta { font-size: 11px; padding: 0 8px 8px; color: #999; }
        .evidence-section-title { font-size: 13px; font-weight: 700; text-transform: uppercase; color: #666; margin: 15px 0 5px; }
        .btn { display: inline-block; padding: 10px 18px; border-radius: 6px; border: none; cursor: pointer; font-weight: 600; text-decoration: none; }
        .btn-primary { background: #0a63bc; color: #fff; }
        .btn-success { background: #28a745; color: #fff; }
        .btn-secondary { background: #6c757d; color: #fff; }
        .form-row { margin-bottom: 12px; }
        .form-row label { display: block; margin-bottom: 5px; font-weight: 600; font-size: 13px; }
        .form-row select, .form-row textarea, .form-row input[type="text"], .form-row input[type="file"] {
            width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 6px; box-sizing: border-box;
        }
        .field-hint { font-size: 12px; color: #777; margin-top: 6px; }
        .evidence-type-toggle { display: flex; gap: 10px; margin-bottom: 10px; }
        .evidence-type-toggle label { font-weight: normal; display: flex; align-items: center; gap: 5px; }
        .timeline-item { padding: 12px 15px; border-left: 3px solid #0a63bc; margin-bottom: 10px; background: #f8f9fa; border-radius: 0 8px 8px 0; }
        .timeline-status { font-weight: 700; text-transform: capitalize; color: #0a63bc; }
        .timeline-meta { font-size: 12px; color: #999; margin-top: 4px; }
        .description-box { background: #f8f9fa; padding: 20px; border-radius: 10px; margin-bottom: 20px; white-space: pre-wrap; }
    </style>
</head>
<body>
    <div class="container detail-wrap">
        <div class="header">
            <div>
                <h1>Complaint Details</h1>
                <span class="department-badge"><?php echo htmlspecialchars($my_department); ?> Department</span>
            </div>
            <div class="header-actions">
                <a href="dashboard.php" class="back-btn">← Back to Dashboard</a>
                <a href="../auth/logout.php" class="logout-btn">Logout</a>
            </div>
        </div>

        <?php if ($success): ?><div class="message-alert message-success"><?php echo htmlspecialchars($success); ?></div><?php endif; ?>
        <?php if ($error): ?><div class="message-alert message-error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

        <div class="complaint-header-box">
            <h2>#<?php echo htmlspecialchars($complaint['complaint_number']); ?> — <?php echo htmlspecialchars($complaint['title']); ?></h2>
            <span class="priority-badge <?php echo priorityClass($complaint['priority']); ?>"><?php echo strtoupper($complaint['priority']); ?></span>
            <span class="status-badge status-<?php echo strtolower($complaint['status']); ?>"><?php echo ucfirst(str_replace('_', ' ', $complaint['status'])); ?></span>
        </div>

        <div class="meta-grid">
            <div class="meta-item"><span class="meta-label">Reported By</span><span class="meta-value"><?php echo htmlspecialchars($complaint['student_name'] ?? 'Unknown'); ?></span></div>
            <div class="meta-item"><span class="meta-label">Category</span><span class="meta-value"><?php echo htmlspecialchars($complaint['category_name'] ?? 'Uncategorized'); ?></span></div>
            <div class="meta-item"><span class="meta-label">Location</span><span class="meta-value"><?php echo htmlspecialchars(trim(($complaint['location_building'] ?? '') . ' ' . ($complaint['location_room'] ?? '')) ?: 'N/A'); ?></span></div>
            <div class="meta-item"><span class="meta-label">Submitted</span><span class="meta-value"><?php echo date('M d, Y', strtotime($complaint['created_at'])); ?></span></div>
            <?php if (($complaint['affected_count'] ?? 1) > 1): ?>
            <div class="meta-item"><span class="meta-label">Affected Students</span><span class="meta-value"><?php echo (int)$complaint['affected_count']; ?></span></div>
            <?php endif; ?>
        </div>

        <div class="card-box">
            <h3>Description</h3>
            <div class="description-box"><?php echo nl2br(htmlspecialchars($complaint['description'])); ?></div>

            <?php if (!empty($attachments)): ?>
                <div class="evidence-section-title">Original Attachments</div>
                <div class="evidence-grid">
                    <?php foreach ($attachments as $a): ?>
                        <?php $ext = strtolower(pathinfo($a['file_path'], PATHINFO_EXTENSION)); ?>
                        <div class="evidence-item">
                            <?php if (in_array($ext, ['jpg','jpeg','png','gif','webp'])): ?>
                                <a href="../<?php echo htmlspecialchars($a['file_path']); ?>" target="_blank"><img src="../<?php echo htmlspecialchars($a['file_path']); ?>" alt="Attachment"></a>
                            <?php else: ?>
                                <a href="../<?php echo htmlspecialchars($a['file_path']); ?>" target="_blank" style="display:block;padding:20px;text-align:center;">📄 <?php echo htmlspecialchars($a['file_name']); ?></a>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- My Assignment -->
        <div class="card-box">
            <h3>My Assignment</h3>

            <div class="assignment-banner <?php echo $assignment_status; ?>">
                <div>
                    <?php if ($assignment_status === 'assigned'): ?>
                        <strong>Assigned to you</strong>
                        <?php if (!empty($complaint['assigned_by_name'])): ?> by your supervisor, <?php echo htmlspecialchars($complaint['assigned_by_name']); ?><?php endif; ?>
                        <?php if (!empty($complaint['assigned_at'])): ?> on <?php echo date('M d, Y g:i A', strtotime($complaint['assigned_at'])); ?><?php endif; ?>
                    <?php elseif ($assignment_status === 'awaiting_confirmation'): ?>
                        <strong>You reported this as resolved.</strong> Awaiting confirmation from your supervisor<?php if (!empty($complaint['assigned_by_name'])): ?>, <?php echo htmlspecialchars($complaint['assigned_by_name']); ?><?php endif; ?>.
                    <?php elseif ($assignment_status === 'resolved'): ?>
                        <strong>Resolution confirmed by your supervisor.</strong> This complaint is closed out for the student.
                    <?php endif; ?>
                </div>
            </div>

            <?php if ($assignment_status === 'assigned'): ?>
                <h4>Upload Evidence Photo</h4>
                <form method="POST" action="" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                    <div class="evidence-type-toggle">
                        <label><input type="radio" name="evidence_type" value="before" checked> Before</label>
                        <label><input type="radio" name="evidence_type" value="after"> After</label>
                        <label><input type="radio" name="evidence_type" value="general"> General</label>
                    </div>
                    <div class="form-row">
                        <input type="file" name="evidence_file" accept="image/*" required>
                    </div>
                    <div class="form-row">
                        <input type="text" name="evidence_caption" placeholder="Caption (optional)">
                    </div>
                    <button type="submit" name="upload_evidence" class="btn btn-secondary">Upload Photo</button>
                </form>

                <hr style="margin: 20px 0; border: none; border-top: 1px solid #eee;">
                <h4>Mark My Work as Resolved</h4>
                <?php if (empty($after_evidence)): ?>
                    <p style="color:#b8860b; font-size:13px;">⚠ Tip: upload an "After" photo above so your supervisor can see the issue was actually fixed.</p>
                <?php endif; ?>
                <form method="POST" action="">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                    <div class="form-row">
                        <textarea name="resolve_message" rows="2" placeholder="What did you do to resolve this?"></textarea>
                    </div>
                    <button type="submit" name="mark_assignment_resolved" class="btn btn-success">Mark as Resolved</button>
                </form>
            <?php elseif ($assignment_status === 'awaiting_confirmation'): ?>
                <p style="color:#666;">Your supervisor will review your evidence and either confirm the resolution or send it back to you for more work. You'll see it here if it comes back.</p>
            <?php endif; ?>
        </div>

        <!-- Evidence Gallery -->
        <?php if (!empty($evidence)): ?>
        <div class="card-box">
            <h3>Resolution Evidence</h3>
            <?php if (!empty($before_evidence)): ?>
                <div class="evidence-section-title">Before</div>
                <div class="evidence-grid">
                    <?php foreach ($before_evidence as $e): ?>
                        <div class="evidence-item">
                            <a href="../<?php echo htmlspecialchars($e['file_path']); ?>" target="_blank"><img src="../<?php echo htmlspecialchars($e['file_path']); ?>" alt="Before"></a>
                            <?php if (!empty($e['caption'])): ?><div class="evidence-caption"><?php echo htmlspecialchars($e['caption']); ?></div><?php endif; ?>
                            <div class="evidence-meta"><?php echo htmlspecialchars($e['uploaded_by_name']); ?> · <?php echo date('M d, g:i A', strtotime($e['created_at'])); ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <?php if (!empty($after_evidence)): ?>
                <div class="evidence-section-title">After</div>
                <div class="evidence-grid">
                    <?php foreach ($after_evidence as $e): ?>
                        <div class="evidence-item">
                            <a href="../<?php echo htmlspecialchars($e['file_path']); ?>" target="_blank"><img src="../<?php echo htmlspecialchars($e['file_path']); ?>" alt="After"></a>
                            <?php if (!empty($e['caption'])): ?><div class="evidence-caption"><?php echo htmlspecialchars($e['caption']); ?></div><?php endif; ?>
                            <div class="evidence-meta"><?php echo htmlspecialchars($e['uploaded_by_name']); ?> · <?php echo date('M d, g:i A', strtotime($e['created_at'])); ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <?php if (!empty($general_evidence)): ?>
                <div class="evidence-section-title">Other Photos</div>
                <div class="evidence-grid">
                    <?php foreach ($general_evidence as $e): ?>
                        <div class="evidence-item">
                            <a href="../<?php echo htmlspecialchars($e['file_path']); ?>" target="_blank"><img src="../<?php echo htmlspecialchars($e['file_path']); ?>" alt="Evidence"></a>
                            <?php if (!empty($e['caption'])): ?><div class="evidence-caption"><?php echo htmlspecialchars($e['caption']); ?></div><?php endif; ?>
                            <div class="evidence-meta"><?php echo htmlspecialchars($e['uploaded_by_name']); ?> · <?php echo date('M d, g:i A', strtotime($e['created_at'])); ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <!-- Quick Status Update: working states only -->
        <?php if ($assignment_status === 'assigned'): ?>
        <div class="card-box">
            <h3>Quick Status Update</h3>
            <?php if (!empty($templates)): ?>
                <div class="templates-section">
                    <label>Quick Templates:</label>
                    <div class="templates-list">
                        <?php foreach ($templates as $template): ?>
                            <?php if (in_array($template['status'], ['under_review', 'in_progress'])): ?>
                            <div class="template-item"
                                 onclick="document.getElementById('status_select').value='<?php echo $template['status']; ?>';
                                          document.getElementById('message_input').value='<?php echo addslashes($template['description']); ?>'">
                                <div class="template-title"><?php echo htmlspecialchars($template['title']); ?></div>
                                <div class="template-desc"><?php echo htmlspecialchars(substr($template['description'], 0, 60)); ?>...</div>
                            </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
            <form method="POST" action="">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <div class="form-row">
                    <label>Change Status:</label>
                    <select name="status" id="status_select" required>
                        <option value="">Select New Status</option>
                        <option value="under_review" <?php echo $complaint['status'] == 'under_review' ? 'selected' : ''; ?>>Under Review</option>
                        <option value="in_progress" <?php echo $complaint['status'] == 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
                    </select>
                    <div class="field-hint">To mark your work resolved, use "Mark as Resolved" above &mdash; your supervisor confirms it before the student is notified.</div>
                </div>
                <div class="form-row">
                    <label>Update Message (optional):</label>
                    <textarea name="update_message" id="message_input" rows="2" placeholder="Add a message about this update..."></textarea>
                </div>
                <button type="submit" name="update_status" class="btn btn-primary">Update Status</button>
            </form>
        </div>
        <?php endif; ?>

        <!-- Timeline -->
        <div class="card-box">
            <h3>Activity Timeline</h3>
            <?php if (empty($timeline)): ?>
                <p style="color:#999;">No activity yet.</p>
            <?php endif; ?>
            <?php foreach ($timeline as $t): ?>
                <div class="timeline-item">
                    <?php if (!empty($t['status'])): ?><div class="timeline-status"><?php echo htmlspecialchars(str_replace('_', ' ', $t['status'])); ?></div><?php endif; ?>
                    <div><?php echo htmlspecialchars($t['description']); ?></div>
                    <div class="timeline-meta"><?php echo htmlspecialchars($t['updated_by_name'] ?? 'System'); ?> · <?php echo date('M d, Y g:i A', strtotime($t['created_at'])); ?></div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>

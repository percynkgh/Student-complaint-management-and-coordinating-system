

function fillTemplate(status, message, complaintId) {
    const forms = document.forms;
    for (let form of forms) {
        if (form.complaint_id && form.complaint_id.value == complaintId) {
            const statusSelect = form.querySelector('select[name="status"]');
            if (statusSelect) {
                for (let option of statusSelect.options) {
                    if (option.value === status) {
                        option.selected = true;
                        break;
                    }
                }
            }
            
            const messageArea = form.querySelector('textarea[name="update_message"]');
            if (messageArea) {
                messageArea.value = message;
            }
            
            form.parentElement.classList.add('update-form-highlight');
            setTimeout(() => {
                form.parentElement.classList.remove('update-form-highlight');
            }, 1000);
            
            break;
        }
    }
}
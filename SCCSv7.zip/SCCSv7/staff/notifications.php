<?php

require_once '../config/security.php';
require_once '../config/complaint_functions.php';

Security::requireLogin();
if (!Security::hasRole('staff')) {
    header("Location: ../unauthorized.php");
    exit();
}

$db = (new Database())->getConnection();
$cm = new ComplaintManager();
$user_id = $_SESSION['user_id'];

// Mark all as read
if (isset($_GET['mark_all_read'])) {
    $cm->markAllNotificationsRead($user_id);
    header("Location: notifications.php");
    exit();
}

// Mark single as read
if (isset($_GET['mark_read']) && isset($_GET['id'])) {
    $cm->markNotificationRead($_GET['id'], $user_id);
    header("Location: notifications.php");
    exit();
}

// Get notifications
$notifications = $cm->getStudentNotifications($user_id, 50);
$unread_count = $cm->getUnreadNotificationCount($user_id);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Notifications - Staff</title>
    <link rel="stylesheet" href="css/staff.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <div>
                <h1>Notifications <small><?php echo $unread_count; ?> unread</small></h1>
            </div>
            <div>
                <?php if ($unread_count > 0): ?>
                    <a href="?mark_all_read=1" class="mark-read-btn">✓ Mark All Read</a>
                <?php endif; ?>
                <a href="dashboard.php" class="back-btn">← Back</a>
            </div>
        </div>
        
        <div class="notifications-list">
            <?php if (empty($notifications)): ?>
                <div class="empty-state">
                    <p>No notifications yet</p>
                    <a href="dashboard.php" class="back-btn">Go to Dashboard</a>
                </div>
            <?php else: ?>
                <?php foreach ($notifications as $notif): ?>
                    <div class="notification-item <?php echo $notif['is_read'] ? '' : 'unread'; ?>">
                        <div class="notification-icon">
                            <?php echo $notif['is_read'] ? '📩' : '🔔'; ?>
                        </div>
                        <div class="notification-content">
                            <div class="notification-message">
                                <?php echo htmlspecialchars($notif['message']); ?>
                            </div>
                            <div class="notification-meta">
                                <?php echo date('M j, Y g:i A', strtotime($notif['created_at'])); ?>
                                <?php if (!empty($notif['complaint_number'])): ?>
                                    • <a href="view_complaint.php?id=<?php echo $notif['complaint_id']; ?>" class="complaint-link">
                                        View Complaint #<?php echo $notif['complaint_number']; ?>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php if (!$notif['is_read']): ?>
                            <div class="notification-actions">
                                <a href="?mark_read=1&id=<?php echo $notif['notification_id']; ?>" class="mark-single-btn">✓ Mark Read</a>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
